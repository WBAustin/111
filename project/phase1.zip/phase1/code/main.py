import os
import argparse

MemSize = 1000  # memory size, 32-bit addressable.

ADD_OP = 1
SUB_OP = 2
OR_OP = 3
AND_OP = 4
XOR_OP = 5
LW_OP = 6
SW_OP = 7
BEQ_OP = 8
BNE_OP = 9
JAL_OP = 10

##netid: wc2761

######### Helper
# The immediate is converted to the signed-extended one
def signed_to_32bits(raw_immediate):
    positive = raw_immediate[0] == '0'
    if positive:
        return '0' * (32 - len(raw_immediate)) + raw_immediate
    # Add the leading 1s
    extended_immediate = '1' * (32 - len(raw_immediate)) + raw_immediate
    return extended_immediate


# Get numeric value
def get_numeric_value(raw_value):
    if isinstance(raw_value, int):
        return raw_value

    if len(raw_value) == 32 and raw_value[0] == '1':
        # This is a negative number
        tmp_str = ''
        idx = raw_value.rfind('1')
        if idx == 0:
            return -(2 ** 31)
        else:
            for i in range(1, 32):
                if i < idx:
                    tmp_str += '1' if raw_value[i] == '0' else '0'
                else:
                    tmp_str += raw_value[i]
            return -int(tmp_str, 2)

    return int(raw_value, 2)


# Get binary form
def to_binary(raw_value, num_bits):
    if raw_value < 0:
        bits = '1' + ('{:0%sb}' % (num_bits - 1)).format(-raw_value)
        tmp_str = '1'
        idx = bits.rfind('1')
        for i in range(1, num_bits):
            if i < idx:
                tmp_str += '1' if bits[i] == '0' else '0'
            else:
                tmp_str += bits[i]
        return tmp_str

    return ('{:0%sb}' % num_bits).format(raw_value)


# Decode the instruction
def decode_instruction(nextState):
    inst = get_numeric_value(nextState.ID['Instr'])
    opcode = to_binary(inst & 0x7F, num_bits=7)
    if opcode == '0110011':
        # R-type instruction
        funct3 = to_binary((inst >> 12) & 0x7, num_bits=3)
        funct7 = to_binary((inst >> 25) & 0x7F, num_bits=7)
        nextState.EX['Rs'] = to_binary((inst >> 15) & 0x1F, num_bits=5)
        nextState.EX['Rt'] = to_binary((inst >> 20) & 0x1F, num_bits=5)
        nextState.EX['Wrt_reg_addr'] = to_binary((inst >> 7) & 0x1F, num_bits=5)
        # Get the mnemonic of the instruction
        if funct3 == '000' and funct7 == '0000000':
            nextState.EX['alu_op'] = ADD_OP
        elif funct3 == '000' and funct7 == '0100000':
            nextState.EX['alu_op'] = SUB_OP
        elif funct3 == '100' and funct7 == '0000000':
            nextState.EX['alu_op'] = XOR_OP
        elif funct3 == '110' and funct7 == '0000000':
            nextState.EX['alu_op'] = OR_OP
        elif funct3 == '111' and funct7 == '0000000':
            nextState.EX['alu_op'] = AND_OP
        nextState.EX['wrt_enable'] = 1

    elif opcode == '0010011' or opcode == '0000011':
        # I-type instruction
        # Get the mnemonic of the instruction
        funct3 = to_binary((inst >> 12) & 0x7, num_bits=3)
        nextState.EX['Rs'] = to_binary((inst >> 15) & 0x1F, num_bits=5)
        nextState.EX['Wrt_reg_addr'] = to_binary((inst >> 7) & 0x1F, num_bits=5)
        nextState.EX['Imm'] = to_binary((inst >> 20) & 0xFFF, 12)
        nextState.EX['is_I_type'] = 1
        if opcode == '0010011':
            nextState.EX['wrt_enable'] = 1
            if funct3 == '000':
                nextState.EX['alu_op'] = ADD_OP
            elif funct3 == '100':
                nextState.EX['alu_op'] = XOR_OP
            elif funct3 == '110':
                nextState.EX['alu_op'] = OR_OP
            elif funct3 == '111':
                nextState.EX['alu_op'] = AND_OP
        elif opcode == '0000011':
            if funct3 == '000':
                nextState.EX['alu_op'] = LW_OP
                nextState.EX['wrt_enable'] = 0

    elif opcode == '0100011':
        # S-type instruction
        funct3 = to_binary((inst >> 12) & 0x7, num_bits=3)
        nextState.EX['Rs'] = to_binary((inst >> 15) & 0x1F, num_bits=5)
        nextState.EX['Rt'] = to_binary((inst >> 20) & 0x1F, num_bits=5)
        imm1 = (inst >> 7) & 0x1F
        imm2 = (inst >> 25) & 0x7F
        nextState.EX['Imm'] = to_binary((imm2 << 5) + imm1, num_bits=12)
        if funct3 == '010':
            nextState.EX['alu_op'] = SW_OP
            nextState.EX['wrt_enable'] = 1

    elif opcode == '1100011':
        # B-type instruction
        funct3 = to_binary((inst >> 12) & 0x7, num_bits=3)
        nextState.EX['Rs'] = to_binary((inst >> 15) & 0x1F, num_bits=5)
        nextState.EX['Rt'] = to_binary((inst >> 20) & 0x1F, num_bits=5)
        imm1 = (inst >> 7) & 0x1F
        imm2 = (inst >> 25) & 0x7F
        nextState.EX['Imm'] = to_binary((((imm1 >> 1) & 0xF) << 1) + ((imm2 & 0x3F) << 5) + \
                                        ((imm1 & 0x1) << 11) + (((imm2 >> 6) & 0x1) << 12), num_bits=13)
        if funct3 == '000':
            nextState.EX['alu_op'] = BEQ_OP
        elif funct3 == '001':
            nextState.EX['alu_op'] = BNE_OP

    elif opcode == '1101111':
        # J-type instruction (JAL)
        nextState.EX['Wrt_reg_addr'] = to_binary((inst >> 7) & 0x1F, num_bits=5)
        imm = (inst >> 12) & 0xFFFFF
        nextState.EX['Imm'] = to_binary((((imm >> 9) & 0x3FF) << 1) + (((imm >> 8) & 0x1) << 11) + \
                                        ((imm & 0xFF) << 12) + (((imm >> 19) & 0x1) << 20), num_bits=21)
        nextState.EX['wrt_enable'] = 1
        nextState.EX['alu_op'] = JAL_OP

    elif opcode == '1111111':
        # Halt
        nextState.IF["nop"] = True


def execute_phase(state, nextState):
    if nextState.EX['alu_op'] in [ADD_OP, SUB_OP, XOR_OP, OR_OP, AND_OP] \
            and nextState.EX['is_I_type'] == 0:
        # R-type instruction
        v1 = get_numeric_value(nextState.EX['Read_data1'])
        v2 = get_numeric_value(nextState.EX['Read_data2'])
        if nextState.EX['alu_op'] == ADD_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 + v2, num_bits=32)
        elif nextState.EX['alu_op'] == SUB_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 - v2, num_bits=32)
        elif nextState.EX['alu_op'] == XOR_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 ^ v2, num_bits=32)
        elif nextState.EX['alu_op'] == OR_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 | v2, num_bits=32)
        elif nextState.EX['alu_op'] == AND_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 & v2, num_bits=32)

    elif nextState.EX['alu_op'] in [ADD_OP, SUB_OP, XOR_OP, OR_OP, AND_OP, LW_OP] \
            and nextState.EX['is_I_type'] == 1:
        # I-type instruction
        extended_imm = get_numeric_value(signed_to_32bits(nextState.EX['Imm']))
        v1 = get_numeric_value(nextState.EX['Read_data1'])
        if nextState.EX['alu_op'] == ADD_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 + extended_imm, num_bits=32)
        elif nextState.EX['alu_op'] == XOR_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 ^ extended_imm, num_bits=32)
        elif nextState.EX['alu_op'] == OR_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 | extended_imm, num_bits=32)
        elif nextState.EX['alu_op'] == AND_OP:
            nextState.MEM['ALUresult'] = to_binary(v1 & extended_imm, num_bits=32)
        elif nextState.EX['alu_op'] == LW_OP:
            nextState.EX['rd_mem'] = to_binary(v1 + extended_imm, num_bits=32)

    elif nextState.EX['alu_op'] == SW_OP:
        # S-type instruction
        v1 = get_numeric_value(nextState.EX['Read_data1'])
        extended_imm = get_numeric_value(signed_to_32bits(nextState.EX['Imm']))
        nextState.EX['wrt_mem'] = to_binary(v1 + extended_imm, num_bits=32)
        nextState.MEM['Store_data'] = nextState.EX['Read_data2']

    elif nextState.EX['alu_op'] in [BEQ_OP, BNE_OP]:
        # B-type instruction
        extended_imm = get_numeric_value(signed_to_32bits(nextState.EX['Imm']))
        if nextState.EX['alu_op'] == BEQ_OP:
            if nextState.EX['Read_data1'] == nextState.EX['Read_data2']:
                nextState.IF['PC'] = state.IF['PC'] + extended_imm
        elif nextState.EX['alu_op'] == BNE_OP:
            if nextState.EX['Read_data1'] != nextState.EX['Read_data2']:
                nextState.IF['PC'] = state.IF['PC'] + extended_imm

    elif nextState.EX['alu_op'] == JAL_OP:
        # J-type instruction
        extended_imm = get_numeric_value(signed_to_32bits(nextState.EX['Imm']))
        nextState.MEM['ALUresult'] = to_binary(state.IF['PC'] + 4, num_bits=32)
        nextState.IF['PC'] = state.IF['PC'] + extended_imm

    nextState.MEM['Rs'] = nextState.EX['Rs']
    nextState.MEM['Rt'] = nextState.EX['Rt']
    nextState.MEM['Wrt_reg_addr'] = nextState.EX['Wrt_reg_addr']
    nextState.MEM['rd_mem'] = nextState.EX['rd_mem']
    nextState.MEM['wrt_mem'] = nextState.EX['wrt_mem']
    nextState.MEM['wrt_enable'] = nextState.EX['wrt_enable']


def access_memory(nextState, dataMem):
    nextState.WB['wrt_enable'] = 0
    if nextState.EX['alu_op'] == LW_OP:
        # LW instruction
        addr = get_numeric_value(nextState.MEM['rd_mem'])
        nextState.WB['Wrt_data'] = dataMem.readDataMem(addr)
        nextState.WB['wrt_enable'] = 1
    elif nextState.EX['alu_op'] == SW_OP:
        # SW instruction
        addr = get_numeric_value(nextState.MEM['wrt_mem'])
        data = get_numeric_value(nextState.MEM['Store_data'])
        dataMem.writeDataMem(addr, data)
    elif nextState.EX['alu_op'] in [ADD_OP, SUB_OP, XOR_OP, OR_OP, AND_OP]:
        # R-type instruction or I-type instruction
        nextState.WB['Wrt_data'] = nextState.MEM['ALUresult']
        nextState.WB['wrt_enable'] = 1
    elif nextState.EX['alu_op'] == JAL_OP:
        # J-type instruction
        nextState.WB['Wrt_data'] = nextState.MEM['ALUresult']
        nextState.WB['wrt_enable'] = 1

    nextState.WB['Rs'] = nextState.MEM['Rs']
    nextState.WB['Rt'] = nextState.MEM['Rt']
    nextState.WB['Wrt_reg_addr'] = nextState.MEM['Wrt_reg_addr']
    nextState.WB['rd_mem'] = nextState.MEM['rd_mem']


def write_registers(nextState, myRF):
    if nextState.WB['wrt_enable']:
        # Write the data to the registers
        reg_addr = get_numeric_value(nextState.WB['Wrt_reg_addr'])
        data = get_numeric_value(nextState.WB['Wrt_data'])
        myRF.writeRF(reg_addr, data)


##########################################################

class InsMem(object):
    def __init__(self, name, ioDir):
        self.id = name

        with open(ioDir + "\\imem.txt") as im:
            self.IMem = [data.replace("\n", "") for data in im.readlines()]

    def readInstr(self, ReadAddress):
        # read instruction memory
        # return 32 bit hex val
        return ''.join(self.IMem[ReadAddress:ReadAddress + 4])


class DataMem(object):
    def __init__(self, name, ioDir):
        self.id = name
        self.ioDir = ioDir
        with open(ioDir + "\\dmem.txt") as dm:
            self.DMem = [data.replace("\n", "") for data in dm.readlines()]

        # Add the remaining memory
        self.DMem += ['00000000' for _ in range(MemSize - len(self.DMem))]

    def readDataMem(self, ReadAddress):
        # read data memory
        # return 32 bit hex val
        return ''.join(self.DMem[ReadAddress:ReadAddress + 4])

    def writeDataMem(self, Address, WriteData):
        # write data into byte addressable memory
        while Address + 3 >= len(self.DMem):
            self.DMem.append('0' * 8)

        bytes = to_binary(WriteData, num_bits=32)
        for i in range(4):
            self.DMem[Address + i] = bytes[i * 8: (i + 1) * 8]

    def outputDataMem(self):
        resPath = self.ioDir + "\\" + self.id + "_DMEMResult.txt"
        with open(resPath, "w") as rp:
            rp.writelines([str(data) + "\n" for data in self.DMem])


class RegisterFile(object):
    def __init__(self, ioDir):
        self.outputFile = ioDir + "RFResult.txt"
        self.Registers = [0x0 for i in range(32)]

    def readRF(self, Reg_addr):
        # Fill in
        return self.Registers[Reg_addr]

    def writeRF(self, Reg_addr, Wrt_reg_data):
        # Fill in
        if Reg_addr > 0:
            self.Registers[Reg_addr] = to_binary(Wrt_reg_data, num_bits=32)

    def outputRF(self, cycle):
        op = ["-" * 70 + "\n", "State of RF after executing cycle:" + str(cycle) + "\n"]
        op.extend([(str(val) if isinstance(val, str) else to_binary(val, num_bits=32)) + "\n"
                   for val in self.Registers])
        if (cycle == 0):
            perm = "w"
        else:
            perm = "a"
        with open(self.outputFile, perm) as file:
            file.writelines(op)


class State(object):
    def __init__(self):
        self.IF = {"nop": False, "PC": 0}
        self.ID = {"nop": False, "Instr": 0}
        self.EX = {"nop": False, "Read_data1": 0, "Read_data2": 0, "Imm": 0, "Rs": 0, "Rt": 0, "Wrt_reg_addr": 0,
                   "is_I_type": False, "rd_mem": 0,
                   "wrt_mem": 0, "alu_op": 0, "wrt_enable": 0}
        self.MEM = {"nop": False, "ALUresult": 0, "Store_data": 0, "Rs": 0, "Rt": 0, "Wrt_reg_addr": 0, "rd_mem": 0,
                    "wrt_mem": 0, "wrt_enable": 0}
        self.WB = {"nop": False, "Wrt_data": 0, "Rs": 0, "Rt": 0, "Wrt_reg_addr": 0, "wrt_enable": 0}


class Core(object):
    def __init__(self, ioDir, imem, dmem):
        self.myRF = RegisterFile(ioDir)
        self.cycle = 0
        self.num_inst = 0
        self.halted = False
        self.ioDir = ioDir
        self.state = State()
        self.nextState = State()
        self.ext_imem = imem
        self.ext_dmem = dmem


class SingleStageCore(Core):
    def __init__(self, ioDir, imem, dmem):
        super(SingleStageCore, self).__init__(ioDir + "\\SS_", imem, dmem)
        self.opFilePath = ioDir + "\\StateResult_SS.txt"

    def step(self):
        # Your implementation
        self.nextState = State()
        # --------------------- IF stage ---------------------
        inst = self.ext_imem.readInstr(self.state.IF['PC'])
        self.nextState.ID['Instr'] = inst
        if self.nextState.ID['Instr'][-7:] == '1111111':
            self.nextState.IF["nop"] = True
            self.nextState.IF['PC'] = self.state.IF['PC']
        else:
            self.nextState.IF['PC'] = self.state.IF['PC'] + 4

            # --------------------- ID stage ---------------------
            # Instruction decode
            decode_instruction(self.nextState)

            # Register read
            rs = get_numeric_value(self.nextState.EX['Rs'])
            rt = get_numeric_value(self.nextState.EX['Rt'])
            if rs > 0:
                self.nextState.EX['Read_data1'] = self.myRF.readRF(rs)
            if rt > 0:
                self.nextState.EX['Read_data2'] = self.myRF.readRF(rt)

            # --------------------- EX stage ---------------------
            # Execute operation or calculate address
            execute_phase(self.state, self.nextState)

            # --------------------- MEM stage --------------------
            # Access memory operand
            access_memory(self.nextState, self.ext_dmem)

            # --------------------- WB stage ---------------------
            # Write result back to register
            write_registers(self.nextState, self.myRF)

        self.halted = False
        if self.state.IF["nop"]:
            self.halted = True
        else:
            self.num_inst += 1

        self.myRF.outputRF(self.cycle)  # dump RF
        self.printState(self.nextState, self.cycle)  # print states after executing cycle 0, cycle 1, cycle 2 ...

        self.state = self.nextState  # The end of the cycle and updates the current state with the values calculated in this cycle
        self.cycle += 1

    def printState(self, state, cycle):
        printstate = ["-" * 70 + "\n", "State after executing cycle: " + str(cycle) + "\n"]
        printstate.append("IF.PC: " + str(state.IF["PC"]) + "\n")
        printstate.append("IF.nop: " + str(state.IF["nop"]) + "\n")

        if (cycle == 0):
            perm = "w"
        else:
            perm = "a"
        with open(self.opFilePath, perm) as wf:
            wf.writelines(printstate)


class FiveStageCore(Core):
    def __init__(self, ioDir, imem, dmem):
        super(FiveStageCore, self).__init__(ioDir + "\\FS_", imem, dmem)
        self.opFilePath = ioDir + "\\StateResult_FS.txt"

    def step(self):
        # Your implementation
        self.num_inst += 1
        # --------------------- WB stage ---------------------

        # --------------------- MEM stage --------------------

        # --------------------- EX stage ---------------------

        # --------------------- ID stage ---------------------

        # --------------------- IF stage ---------------------

        self.halted = True
        if self.state.IF["nop"] and self.state.ID["nop"] and self.state.EX["nop"] and self.state.MEM["nop"] and \
                self.state.WB["nop"]:
            self.halted = True

        self.myRF.outputRF(self.cycle)  # dump RF
        self.printState(self.nextState, self.cycle)  # print states after executing cycle 0, cycle 1, cycle 2 ...

        self.state = self.nextState  # The end of the cycle and updates the current state with the values calculated in this cycle
        self.cycle += 1

    def printState(self, state, cycle):
        printstate = ["-" * 70 + "\n", "State after executing cycle: " + str(cycle) + "\n"]
        printstate.extend(["IF." + key + ": " + str(val) + "\n" for key, val in state.IF.items()])
        printstate.extend(["ID." + key + ": " + str(val) + "\n" for key, val in state.ID.items()])
        printstate.extend(["EX." + key + ": " + str(val) + "\n" for key, val in state.EX.items()])
        printstate.extend(["MEM." + key + ": " + str(val) + "\n" for key, val in state.MEM.items()])
        printstate.extend(["WB." + key + ": " + str(val) + "\n" for key, val in state.WB.items()])

        if (cycle == 0):
            perm = "w"
        else:
            perm = "a"
        with open(self.opFilePath, perm) as wf:
            wf.writelines(printstate)


if __name__ == "__main__":

    # parse arguments for input file location
    parser = argparse.ArgumentParser(description='RV32I processor')
    parser.add_argument('--iodir', default="", type=str, help='Directory containing the input files.')
    args = parser.parse_args()

    ioDir = os.path.abspath(args.iodir)
    print("IO Directory:", ioDir)

    imem = InsMem("Imem", ioDir)
    dmem_ss = DataMem("SS", ioDir)
    dmem_fs = DataMem("FS", ioDir)

    ssCore = SingleStageCore(ioDir, imem, dmem_ss)
    fsCore = FiveStageCore(ioDir, imem, dmem_fs)

    while (True):
        if not ssCore.halted:
            ssCore.step()

        if not fsCore.halted:
            fsCore.step()

        if ssCore.halted and fsCore.halted:
            break

    # output the performance metrics
    metrics_fp = open(os.path.join(ioDir, 'PerformanceMetrics.txt'), 'w', newline='')
    metrics_fp.write('Performance of Single Stage:\n')
    metrics_fp.write('#Cycles -> %d\n' % ssCore.cycle)
    metrics_fp.write('#Instructions -> %d\n' % ssCore.num_inst)
    ss_CPI = ssCore.cycle / ssCore.num_inst
    ss_IPC = ssCore.num_inst / ssCore.cycle
    metrics_fp.write('CPI -> %s\n' % ss_CPI)
    metrics_fp.write('IPC -> %s\n' % ss_IPC)
    metrics_fp.write('\nPerformance of Five Stage:\n')
    metrics_fp.write('#Cycles -> %d\n' % fsCore.cycle)
    metrics_fp.write('#Instructions -> %d\n' % fsCore.num_inst)
    fs_CPI = fsCore.cycle / fsCore.num_inst
    fs_IPC = fsCore.num_inst / fsCore.cycle
    metrics_fp.write('CPI -> %s\n' % fs_CPI)
    metrics_fp.write('IPC -> %s\n' % fs_IPC)
    metrics_fp.close()

    # dump SS and FS data mem.
    dmem_ss.outputDataMem()
    dmem_fs.outputDataMem()
